﻿using System;
using System.Collections.Generic;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;

namespace DocumentDB
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Run();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
        }

        private static async void Run()
        {
            #region Connection Information

            const string endpoint = @"https://[your document db name].documents.azure.com:443/";
            const string authKey =
                "auth key";

            #endregion

            using (var client = new DocumentClient(new Uri(endpoint), authKey))
            {
                #region Create database

                #endregion

                #region Create collection

                #endregion

                #region Create documents

                #region Strongly typed

                #endregion

                #region Dynamic types


                #endregion

                #endregion

                #region Query documents

                #region LINQ

                #endregion

                #region SQL like querying

                #endregion

                #endregion

                #region Database cleanup

                #endregion
            }
        }
    }

    [Serializable]
    internal class Family
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public string LastName { get; set; }
        public IEnumerable<Parent> Parents { get; set; }
        public IEnumerable<Child> Children { get; set; }
        public Address Address { get; set; }
        public bool IsRegistered { get; set; }
    }

    [Serializable]
    internal class Parent
    {
        public string FirstName { get; set; }
    }

    [Serializable]
    internal class Child
    {
        public string FirstName { get; set; }
        public string Gender { get; set; }
        public int Grade { get; set; }
        public IEnumerable<Pet> Pets { get; set; }
    }

    [Serializable]

    internal class Pet
    {
        public string GivenName { get; set; }
    }

    [Serializable]
    internal class Address
    {
        public string State { get; set; }
        public string County { get; set; }
        public string City { get; set; }
    }
}
