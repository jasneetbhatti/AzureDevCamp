&'.\SqlPackageDlls\SqlPackage.exe'  `
/Action:Publish `
/SourceFile:'.\DACPACs\DB.dacpac' `
/TargetServerName:'[your db server name].database.windows.net' `
/TargetDatabaseName:'[your db name]' `
/TargetUser:'[login]' `
/TargetPassword:'[password]' `
/p:GenerateSmartDefaults=True 2>&1 | out-file '.\log.txt'