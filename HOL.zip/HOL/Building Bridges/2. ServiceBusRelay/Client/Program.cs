﻿using System;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create ChannelFactory for local endpoint with NetTcpBinding

            // Create Channel

            // Invoke operation


            // Create ChannelFactory for relay endpoint with NetTcpRelayBinding

            // Create Channel

            // Invoke operation

            Console.ReadLine();
        }
    }
}
