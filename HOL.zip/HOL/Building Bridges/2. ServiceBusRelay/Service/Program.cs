﻿using System;

namespace Service
{
    class Service:IWho
    {
        public string Who()
        {
            // Implement Operation
            return "";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Create Service Host

            // Add Service Endpoint with local endpoint address

            // Open host

            Console.WriteLine("Press enter to close");
            Console.ReadLine();
        }
    }
}
